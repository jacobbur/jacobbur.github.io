package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.EditText;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.Toast;


import java.util.ArrayList;

public class add_entry extends AppCompatActivity {

    private ArrayList<EditText> data = new ArrayList<EditText>();
    private ArrayList<EditText> data1 = new ArrayList<EditText>();
    private ArrayList<EditText> data2 = new ArrayList<EditText>();
    private ArrayList<EditText> data3 = new ArrayList<EditText>();

    private TableLayout table;

    EditText addid, addname, addloc, addnum;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_entry);

        addid = findViewById(R.id.addid);
        addname = findViewById(R.id.addname);
        addloc = findViewById(R.id.addloc);
        submit = findViewById(R.id.submit);
        addnum = findViewById(R.id.addnum);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = addid.getText().toString();
                String name = addname.getText().toString();
                String loc = addloc.getText().toString();
                String num = addnum.getText().toString();

                data.add(addid);
                data1.add(addname);
                data2.add(addloc);
                data3.add(addnum);

                TableLayout table = (TableLayout) findViewById(R.id.tb1);

                if (id.equals("") || name.equals("") || loc.equals("") || num.equals("")) {
                    Toast.makeText(add_entry.this, "Please enter required fields", Toast.LENGTH_SHORT);
                }else {
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);

            }
            }
        });
    }
}